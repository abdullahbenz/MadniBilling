package com.madni.billing

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.hardware.usb.*
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

object Fmt {
    fun center(s: String, w: Int) = " ".repeat(maxOf(0, (w - s.length) / 2)) + s
    fun body(r: Rec, w: Int, reprint: Boolean): String {
        val d = Date(r.ts); val sep = "-".repeat(w); val sb = StringBuilder()
        sb.append(sep).append('\n')
        sb.append("Receipt No: ").append(if (r.no == 0L) "(set on print)" else "%04d".format(r.no)).append('\n')
        sb.append("Date: ").append(SimpleDateFormat("dd-MM-yyyy", Locale.US).format(d)).append('\n')
        sb.append("Time: ").append(SimpleDateFormat("hh:mm a", Locale.US).format(d)).append('\n')
        sb.append(sep).append('\n')
        val aw = 13; val nw = w - 4 - aw
        sb.append("Item".padEnd(nw) + "Qty".padStart(4) + "Amount".padStart(aw)).append('\n')
        r.items.forEach { sb.append(it.name.take(nw).padEnd(nw) + it.qty.toString().padStart(4) + Money.fmt(it.sub).padStart(aw)).append('\n') }
        sb.append(sep).append('\n')
        sb.append("TOTAL: " + Money.fmt(r.total)).append('\n')
        sb.append(sep).append('\n')
        if (reprint) sb.append(center("*** REPRINT ***", w)).append('\n')
        sb.append(center("Thank you for shopping with us!", w)).append('\n')
        return sb.toString()
    }
    fun text(r: Rec, w: Int, reprint: Boolean) = center("MADNI BURKHA HOUSE", w) + "\n" + body(r, w, reprint)

    private fun wrap(w: Int, title: String, body: String): ByteArray {
        val o = ByteArrayOutputStream()
        fun b(vararg x: Int) = x.forEach { o.write(it) }
        b(0x1B, 0x40)                                   // initialise
        b(0x1B, 0x61, 1, 0x1B, 0x45, 1)                 // centre + bold
        if (w >= 48) b(0x1D, 0x21, 0x10) else b(0x1D, 0x21, 0x01)
        o.write((title + "\n").toByteArray(Charsets.US_ASCII))
        b(0x1D, 0x21, 0, 0x1B, 0x45, 0, 0x1B, 0x61, 0) // normal + left
        o.write(body.toByteArray(Charsets.US_ASCII))
        o.write("\n\n\n".toByteArray())
        b(0x1D, 0x56, 0x42, 0)                          // feed + partial cut (ignored if no cutter)
        return o.toByteArray()
    }
    fun escpos(r: Rec, w: Int, reprint: Boolean) = wrap(w, "MADNI BURKHA HOUSE", body(r, w, reprint))
    fun test(w: Int) = wrap(w, "MADNI BURKHA HOUSE", "-".repeat(w) + "\nTEST PRINT\nPrinter is working.\n" + "-".repeat(w) + "\n")
}

object Printers {
    private val SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun bt(ctx: Context, mac: String, data: ByteArray): String? {
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return "This phone has no Bluetooth."
        if (!ad.isEnabled) return "Bluetooth is turned off. Turn it on and retry."
        var s: android.bluetooth.BluetoothSocket? = null
        try {
            val dev = ad.getRemoteDevice(mac)
            ad.cancelDiscovery()
            s = dev.createRfcommSocketToServiceRecord(SPP)
            try { s.connect() } catch (e: IOException) {
                try { s.close() } catch (_: Exception) {}
                // fallback used by some cheap printers
                s = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(dev, 1) as android.bluetooth.BluetoothSocket
                s.connect()
            }
            val os = s.outputStream
            var o = 0
            while (o < data.size) { val n = minOf(512, data.size - o); os.write(data, o, n); os.flush(); o += n; Thread.sleep(30) }
            Thread.sleep(800)
            return null
        } catch (e: SecurityException) { return "Bluetooth permission denied."
        } catch (e: Exception) { return "Could not print over Bluetooth: ${e.message}. Is the printer on, in range and paired?"
        } finally { try { s?.close() } catch (_: Exception) {} }
    }

    fun usb(um: UsbManager, d: UsbDevice, data: ByteArray): String? {
        var ep: UsbEndpoint? = null; var itf: UsbInterface? = null
        for (i in 0 until d.interfaceCount) {
            val x = d.getInterface(i)
            for (j in 0 until x.endpointCount) {
                val e = x.getEndpoint(j)
                if (e.type == UsbConstants.USB_ENDPOINT_XFER_BULK && e.direction == UsbConstants.USB_DIR_OUT) { itf = x; ep = e; break }
            }
            if (ep != null) break
        }
        if (ep == null || itf == null) return "This USB device has no printer data endpoint (unsupported)."
        val c = um.openDevice(d) ?: return "Could not open the USB device."
        try {
            if (!c.claimInterface(itf, true)) return "Could not take control of the USB printer."
            var o = 0
            while (o < data.size) {
                val n = minOf(4096, data.size - o)
                if (c.bulkTransfer(ep, data.copyOfRange(o, o + n), n, 5000) < 0) return "USB write failed. Check the cable."
                o += n
            }
            return null
        } catch (e: Exception) { return "USB error: ${e.message}" } finally { c.close() }
    }
}

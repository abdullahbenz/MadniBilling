package com.madni.billing

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.*
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

@SuppressLint("MissingPermission", "SetTextI18n")
class MainActivity : Activity() {
    private val PRIMARY = 0xFF0F5C4D.toInt(); private val RED = 0xFFB3261E.toInt(); private val GREY = 0xFF5F6B68.toInt()
    private val ACT = "com.madni.billing.USB_PERM"
    private lateinit var db: Db
    private lateinit var sp: SharedPreferences
    private val bill = mutableListOf<Item>()
    private var pendingNo: Long? = null          // receipt saved in DB but not confirmed printed
    private val cats = listOf("Dupatta", "Burkha", "Abaya", "Chadar", "Hijab Cap", "Gloves")
    private val h = Handler(Looper.getMainLooper())
    private var clock: TextView? = null
    private var cur = "home"
    private val tick = object : Runnable {
        override fun run() { clock?.text = SimpleDateFormat("EEE, dd-MM-yyyy   hh:mm:ss a", Locale.US).format(Date()); h.postDelayed(this, 1000) }
    }
    private val usbRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            toast(if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) "USB permission granted." else "USB permission denied.")
            if (cur == "printer") printerScreen()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this); sp = getSharedPreferences("s", 0)
        sp.getString("draft", "")!!.lines().filter { it.isNotBlank() }.forEach {
            val p = it.split("|", limit = 3); bill.add(Item(p[2], p[0].toLong(), p[1].toInt()))
        }
        val pn = sp.getLong("pend", 0L); pendingNo = if (pn == 0L) null else pn
        val f = IntentFilter(ACT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbRx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(usbRx, f)
        home()
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(usbRx) }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (cur != "home") home() else super.onBackPressed() }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { if (cur == "printer") printerScreen() }

    // ---------- helpers ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
    private fun tv(s: String, sz: Float = 16f, bold: Boolean = false, color: Int = 0xFF222222.toInt()) =
        TextView(this).apply { text = s; textSize = sz; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun btn(s: String, color: Int = PRIMARY, f: () -> Unit) = Button(this).apply {
        text = s; textSize = 17f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(color)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun screen(name: String, v: View) {
        cur = name; if (name != "home") clock = null
        setContentView(ScrollView(this).apply { addView(v); isFillViewport = true; setBackgroundColor(0xFFF4F7F6.toInt()) })
    }
    private fun msg(title: String, m: String, ok: () -> Unit = {}) {
        AlertDialog.Builder(this).setTitle(title).setMessage(m).setPositiveButton("OK") { _, _ -> ok() }.show()
    }
    private fun confirm(title: String, m: String, yes: String, f: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(m).setPositiveButton(yes) { _, _ -> f() }.setNegativeButton("No", null).show()
    }
    private fun persist() {
        sp.edit().putString("draft", bill.joinToString("\n") { "${it.price}|${it.qty}|${it.name}" }).putLong("pend", pendingNo ?: 0L).commit()
    }
    private fun width() = if (sp.getString("paper", "58") == "80") 48 else 32
    private fun total() = bill.sumOf { it.sub }
    private fun mono(s: String) = tv(s, 12f, false).apply {
        typeface = Typeface.MONOSPACE; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8)); setTextColor(Color.BLACK)
    }

    // ---------- home / bill ----------
    private fun home() {
        val c = col()
        c.addView(tv("MADNI BURKHA HOUSE", 26f, true, Color.WHITE).apply { gravity = android.view.Gravity.CENTER; setBackgroundColor(PRIMARY); setPadding(0, dp(16), 0, dp(4)) })
        clock = tv("", 16f, false, Color.WHITE).apply { gravity = android.view.Gravity.CENTER; setBackgroundColor(PRIMARY); setPadding(0, 0, 0, dp(16)) }
        c.addView(clock)
        if (pendingNo != null) c.addView(tv("Receipt %04d is saved but NOT confirmed printed. Tap Review & Print to retry.".format(pendingNo), 15f, true, RED).apply { setPadding(0, dp(8), 0, 0) })
        c.addView(tv("Tap a category, then enter the price", 15f, false, GREY).apply { setPadding(0, dp(10), 0, dp(4)) })
        cats.chunked(2).forEach { row ->
            val r = LinearLayout(this)
            row.forEach { n ->
                r.addView(btn(n) { itemDialog(n, null, -1) }.apply {
                    textSize = 20f; layoutParams = LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                })
            }
            c.addView(r)
        }
        c.addView(tv("Current Bill", 20f, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        if (bill.isEmpty()) c.addView(tv("No items yet.", 16f, false, GREY))
        bill.forEachIndexed { i, it ->
            val r = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)) }
            r.addView(tv("${it.name}\n${Money.fmt(it.price)} x ${it.qty} = ${Money.fmt(it.sub)}", 16f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            r.addView(Button(this).apply { text = "Edit"; isAllCaps = false; setOnClickListener { itemDialog(it.name, bill[i], i) } }.also { b -> b.setOnClickListener { itemDialog(bill[i].name, bill[i], i) } })
            r.addView(Button(this).apply { text = "X"; setTextColor(RED); setOnClickListener { bill.removeAt(i); persist(); home() } })
            c.addView(r, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        }
        c.addView(tv("TOTAL: " + Money.fmt(total()), 24f, true, PRIMARY).apply { setPadding(0, dp(10), 0, 0) })
        c.addView(btn("Review & Print") { if (bill.isEmpty()) toast("Add at least one item.") else preview() })
        c.addView(btn("Cancel Bill", RED) { if (bill.isEmpty()) toast("Nothing to cancel.") else confirm("Cancel bill?", "All items on this bill will be discarded.", "Yes, cancel") { discard() } })
        c.addView(btn("New Bill", GREY) { if (bill.isEmpty()) toast("Bill is already empty.") else confirm("Start new bill?", "The current unfinished bill will be discarded.", "Yes, new bill") { discard() } })
        c.addView(btn("Receipt History", GREY) { history() })
        c.addView(btn("Printer Settings", GREY) { printerScreen() })
        screen("home", c); h.post(tick)
    }
    private fun discard() { bill.clear(); pendingNo = null; persist(); home() }

    private fun itemDialog(name: String, ex: Item?, idx: Int) {
        val p = EditText(this).apply { hint = "Price (Rs.)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; textSize = 24f; if (ex != null) setText(Money.plain(ex.price)) }
        val q = EditText(this).apply { hint = "Quantity"; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 24f; setText((ex?.qty ?: 1).toString()) }
        val l = col().apply { addView(tv("Price (Rs.)")); addView(p); addView(tv("Quantity")); addView(q) }
        val d = AlertDialog.Builder(this).setTitle(name).setView(l).setPositiveButton(if (ex == null) "Add to Bill" else "Save", null).setNegativeButton("Cancel", null).create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
        p.requestFocus()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val pr = Money.parse(p.text.toString()); val qt = q.text.toString().trim().toIntOrNull()
            if (pr == null) { p.error = "Enter a price above 0 (max 2 decimals)"; return@setOnClickListener }
            if (qt == null || qt < 1 || qt > 9999) { q.error = "Quantity 1 - 9999"; return@setOnClickListener }
            if (ex == null) bill.add(Item(name, pr, qt)) else { bill[idx].price = pr; bill[idx].qty = qt }
            persist(); d.dismiss(); home()
        }
    }

    // ---------- preview & print ----------
    private fun preview() {
        val c = col()
        c.addView(tv("Receipt Preview", 22f, true))
        val tmp = Rec(pendingNo ?: 0L, if (pendingNo != null) (db.get(pendingNo!!)?.ts ?: System.currentTimeMillis()) else System.currentTimeMillis(), total(), false, 0, bill)
        c.addView(mono(Fmt.text(tmp, width(), false)))
        c.addView(tv("Final date/time and receipt number are fixed when you confirm.", 13f, false, GREY))
        c.addView(btn("Confirm and Print") { confirmPrint() })
        c.addView(btn("Edit Bill", GREY) { home() })
        c.addView(btn("Cancel Bill", RED) { confirm("Cancel bill?", "All items will be discarded.", "Yes, cancel") { discard() } })
        screen("prev", c)
    }
    private fun confirmPrint() {
        if (bill.isEmpty()) return
        val no = db.save(pendingNo, bill); pendingNo = no; persist()   // same receipt number on every retry
        val rec = db.get(no) ?: return
        sendBytes(Fmt.escpos(rec, width(), false)) { err ->
            if (err == null) {
                db.markPrinted(no); bill.clear(); pendingNo = null; persist()
                msg("Printed", "Receipt %04d sent to the printer. Ready for the next customer.".format(no)) { home() }
            } else {
                AlertDialog.Builder(this).setTitle("Print failed").setCancelable(false)
                    .setMessage("$err\n\nReceipt %04d is saved and your bill is kept. No duplicate will be created on retry.".format(no))
                    .setPositiveButton("Retry") { _, _ -> confirmPrint() }
                    .setNeutralButton("Paper did print") { _, _ -> db.markPrinted(no); bill.clear(); pendingNo = null; persist(); home() }
                    .setNegativeButton("Back to bill") { _, _ -> home() }.show()
            }
        }
    }
    private fun sendBytes(data: ByteArray, cb: (String?) -> Unit) {
        if (sp.getString("mode", "bt") == "bt") {
            val mac = sp.getString("btMac", null) ?: return cb("No Bluetooth printer selected. Open Printer Settings.")
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT), 1); return cb("Bluetooth permission needed. Allow it, then retry.")
            }
            Thread { val e = Printers.bt(this, mac, data); runOnUiThread { cb(e) } }.start()
        } else {
            val um = getSystemService(USB_SERVICE) as UsbManager
            val key = sp.getString("usbKey", null) ?: return cb("No USB printer selected. Open Printer Settings.")
            val d = um.deviceList.values.firstOrNull { "${it.vendorId}:${it.productId}" == key } ?: return cb("USB printer not detected. Check the OTG cable and printer power.")
            if (!um.hasPermission(d)) { requestUsb(d); return cb("USB permission needed. Tap Allow on the popup, then retry.") }
            Thread { val e = Printers.usb(um, d, data); runOnUiThread { cb(e) } }.start()
        }
    }
    private fun requestUsb(d: UsbDevice) {
        val um = getSystemService(USB_SERVICE) as UsbManager
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        um.requestPermission(d, PendingIntent.getBroadcast(this, 0, Intent(ACT).setPackage(packageName), fl))
    }

    // ---------- history ----------
    private fun history() {
        val c = col(); c.addView(tv("Receipt History", 22f, true))
        val s = EditText(this).apply { hint = "Search by receipt no. or date (dd-MM-yyyy)"; setSingleLine() }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun fill(q: String) {
            list.removeAllViews()
            val rs = db.list(q)
            if (rs.isEmpty()) list.addView(tv("No receipts found.", 16f, false, GREY))
            rs.forEach { r ->
                val dt = Date(r.ts)
                list.addView(btn("#%04d   %s  %s\n%s%s".format(r.no, SimpleDateFormat("dd-MM-yyyy", Locale.US).format(dt), SimpleDateFormat("hh:mm a", Locale.US).format(dt),
                    Money.fmt(r.total), if (r.printed) "" else "   (NOT PRINTED)"), if (r.printed) PRIMARY else RED) { detail(r.no) })
            }
        }
        s.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { fill(e.toString()) }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        c.addView(s); c.addView(list); fill("")
        c.addView(btn("Back", GREY) { home() })
        screen("hist", c)
    }
    private fun detail(no: Long) {
        val r = db.get(no) ?: return
        val c = col(); c.addView(tv("Receipt %04d".format(no), 22f, true))
        c.addView(mono(Fmt.text(r, width(), false)))
        if (r.reprints > 0) c.addView(tv("Reprinted ${r.reprints} time(s)", 14f, false, GREY))
        c.addView(btn("Reprint") {
            sendBytes(Fmt.escpos(r, width(), true)) { e ->
                if (e == null) { if (r.printed) db.addReprint(no) else db.markPrinted(no); msg("Done", "Sent to printer. No new receipt was created.") { detail(no) } }
                else msg("Print failed", e)
            }
        })
        c.addView(btn("Back", GREY) { history() })
        screen("detail", c)
    }

    // ---------- printer settings ----------
    private fun radio(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) = RadioGroup(this).apply {
        opts.forEach { (l, v) -> addView(RadioButton(context).apply { text = l; textSize = 17f; id = View.generateViewId(); tag = v; isChecked = (v == sel) }) }
        setOnCheckedChangeListener { g, id -> on(g.findViewById<View>(id).tag as String) }
    }
    private fun printerScreen() {
        val c = col(); c.addView(tv("Printer Settings", 24f, true))
        val mode = sp.getString("mode", "bt")!!
        c.addView(tv("Connection method", 16f, true).apply { setPadding(0, dp(10), 0, 0) })
        c.addView(radio(listOf("Bluetooth" to "bt", "USB (OTG cable)" to "usb"), mode) { sp.edit().putString("mode", it).apply(); printerScreen() })
        c.addView(tv("Paper width", 16f, true))
        c.addView(radio(listOf("58 mm" to "58", "80 mm" to "80"), sp.getString("paper", "58")!!) { sp.edit().putString("paper", it).apply() })
        c.addView(tv("Status", 16f, true).apply { setPadding(0, dp(10), 0, 0) })
        if (mode == "bt") {
            c.addView(tv("Selected: " + (sp.getString("btName", null) ?: "none"), 16f))
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT), 1)
                c.addView(tv("Allow the Bluetooth permission to list paired printers.", 15f, false, RED))
            } else {
                val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (ad == null) c.addView(tv("This phone has no Bluetooth.", 15f, false, RED))
                else if (!ad.isEnabled) c.addView(tv("Bluetooth is off. Turn it on.", 15f, false, RED))
                else {
                    c.addView(tv("Paired devices (tap to select your printer):", 15f, false, GREY))
                    ad.bondedDevices.forEach { d ->
                        val ok = d.address == sp.getString("btMac", null)
                        c.addView(btn((if (ok) "[SELECTED] " else "") + (d.name ?: "Unknown") + "\n" + d.address, if (ok) PRIMARY else GREY) {
                            sp.edit().putString("btMac", d.address).putString("btName", d.name ?: "Unknown").apply(); printerScreen() })
                    }
                }
            }
            c.addView(btn("Pair a new printer (Bluetooth settings)", GREY) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        } else {
            val um = getSystemService(USB_SERVICE) as UsbManager
            c.addView(tv("Selected: " + (sp.getString("usbName", null) ?: "none"), 16f))
            if (um.deviceList.isEmpty()) c.addView(tv("No USB device detected. Connect the printer with an OTG cable and power it on.", 15f, false, RED))
            um.deviceList.values.forEach { d ->
                val key = "${d.vendorId}:${d.productId}"; val ok = key == sp.getString("usbKey", null)
                val isPr = (0 until d.interfaceCount).any { d.getInterface(it).interfaceClass == 7 }
                val nm = (d.productName ?: "USB device") + (if (isPr) " (printer)" else "")
                c.addView(btn((if (ok) "[SELECTED] " else "") + nm + "\n" + key + (if (um.hasPermission(d)) "  - permission OK" else "  - tap to authorise"), if (ok) PRIMARY else GREY) {
                    sp.edit().putString("usbKey", key).putString("usbName", nm).apply(); if (!um.hasPermission(d)) requestUsb(d) else printerScreen() })
            }
        }
        c.addView(btn("Test Print") { sendBytes(Fmt.test(width())) { e -> msg(if (e == null) "Test sent" else "Test failed", e ?: "Check that the paper printed.") } })
        c.addView(btn("Forget selected printer", RED) { sp.edit().remove(if (mode == "bt") "btMac" else "usbKey").remove(if (mode == "bt") "btName" else "usbName").apply(); printerScreen() })
        c.addView(tv("Note: the app connects only while printing and disconnects afterwards, so there is nothing to keep connected.\n\nTroubleshooting:\n- Printer on, paper loaded, cover closed.\n- Bluetooth: pair first in Android Bluetooth settings (PIN is usually 0000 or 1234), then select it here.\n- USB: use an OTG adapter/cable, accept the permission popup.\n- Garbled or cut-off text: switch paper width 58/80 mm.\n- The app cannot tell which connection types your printer supports; if one fails, try the other.", 14f, false, GREY).apply { setPadding(0, dp(12), 0, 0) })
        c.addView(btn("Back", GREY) { home() })
        screen("printer", c)
    }
}

package com.madni.billing

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.*

/** Prices are stored in paisa (Long) so totals are always exact. */
data class Item(var name: String, var price: Long, var qty: Int) { val sub get() = price * qty }
data class Rec(val no: Long, val ts: Long, val total: Long, val printed: Boolean, val reprints: Int, val items: List<Item>)

object Money {
    fun plain(m: Long) = if (m % 100 == 0L) "${m / 100}" else "%d.%02d".format(m / 100, m % 100)
    fun fmt(m: Long) = "Rs. " + plain(m)
    fun parse(s: String): Long? {
        val t = s.trim()
        if (!Regex("""\d{1,9}(\.\d{1,2})?""").matches(t)) return null
        val v = BigDecimal(t).movePointRight(2).toLong()
        return if (v > 0) v else null
    }
}

class Db(c: Context) : SQLiteOpenHelper(c, "madni.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        // AUTOINCREMENT: receipt numbers are never reused
        d.execSQL("CREATE TABLE receipts(no INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, total INTEGER, printed INTEGER DEFAULT 0, reprints INTEGER DEFAULT 0)")
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, rno INTEGER, name TEXT, price INTEGER, qty INTEGER)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    /** no == null creates a new receipt; otherwise updates the same (unprinted) receipt, so retries never duplicate. */
    fun save(no: Long?, items: List<Item>): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val total = items.sumOf { it.sub }
            val rn: Long = if (no == null) {
                db.insert("receipts", null, ContentValues().apply { put("ts", System.currentTimeMillis()); put("total", total) })
            } else {
                db.update("receipts", ContentValues().apply { put("total", total) }, "no=?", arrayOf("$no"))
                db.delete("items", "rno=?", arrayOf("$no"))
                no
            }
            items.forEach { i ->
                db.insert("items", null, ContentValues().apply { put("rno", rn); put("name", i.name); put("price", i.price); put("qty", i.qty) })
            }
            db.setTransactionSuccessful()
            return rn
        } finally { db.endTransaction() }
    }
    fun markPrinted(no: Long) { writableDatabase.execSQL("UPDATE receipts SET printed=1 WHERE no=?", arrayOf<Any>(no)) }
    fun addReprint(no: Long) { writableDatabase.execSQL("UPDATE receipts SET reprints=reprints+1 WHERE no=?", arrayOf<Any>(no)) }

    fun list(q: String): List<Rec> {
        val out = mutableListOf<Rec>()
        readableDatabase.rawQuery("SELECT no,ts,total,printed,reprints FROM receipts ORDER BY no DESC", null).use { c ->
            while (c.moveToNext()) out.add(Rec(c.getLong(0), c.getLong(1), c.getLong(2), c.getInt(3) == 1, c.getInt(4), emptyList()))
        }
        val s = q.trim()
        if (s.isEmpty()) return out
        val df = SimpleDateFormat("dd-MM-yyyy", Locale.US)
        return out.filter { "%04d".format(it.no).contains(s) || df.format(Date(it.ts)).contains(s) }
    }
    fun get(no: Long): Rec? {
        val r = list("").firstOrNull { it.no == no } ?: return null
        val its = mutableListOf<Item>()
        readableDatabase.rawQuery("SELECT name,price,qty FROM items WHERE rno=? ORDER BY id", arrayOf("$no")).use { c ->
            while (c.moveToNext()) its.add(Item(c.getString(0), c.getLong(1), c.getInt(2)))
        }
        return r.copy(items = its)
    }
}

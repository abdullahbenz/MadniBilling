# Madni Burkha House - Offline Billing & Receipt Printing (Android)

Native Kotlin app, no internet, no third-party libraries. SQLite for history. ESC/POS over Bluetooth (SPP) and USB (OTG).

## Get the APK (no coding needed)
1. Create a free GitHub account, make a new repository, upload all files of this folder (keep the .github folder).
2. Open the "Actions" tab > "Build APK" > wait ~3 min > download artifact "MadniBilling-APK" > unzip > app-debug.apk.
(Or: install Android Studio, open this folder, Build > Build APK(s).)

## Install on the phone
Copy app-debug.apk to the phone, open it, allow "Install unknown apps" when asked, tap Install.

## Bluetooth printer
1. Turn the printer on. Android Settings > Bluetooth > pair it (PIN 0000 or 1234).
2. App > Printer Settings > Bluetooth > tap your printer > choose 58/80 mm > Test Print.

## USB printer (OTG)
1. Plug printer into the phone with a USB OTG cable/adapter, power the printer on.
2. App > Printer Settings > USB > tap the printer > Allow the popup > Test Print.

## Requirements and limits
- Printer must understand ESC/POS (most 58/80 mm thermal printers do). Bluetooth printer must be Classic Bluetooth (SPP); BLE-only printers are not supported.
- USB printer must expose a standard bulk-out endpoint (printer class 7 is typical); the phone must support USB host/OTG.
- Android 5.0+. Prices are stored exactly (paisa); receipt numbers never reused.
- Text is ASCII only. Cutter command is sent; printers without a cutter ignore it.
